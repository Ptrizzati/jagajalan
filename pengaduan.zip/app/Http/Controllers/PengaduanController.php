<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pengaduan;
use App\Models\Tanggapan;
use App\Http\Controllers\IndonesiaController;
use RealRashid\SweetAlert\Facades\Alert;

class PengaduanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $items = Pengaduan::all();
        return view('pages.admin.pengaduan.index',[
            'items' => $items
        ]);


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $item = Pengaduan::with([
            'details', 'user'
        ])->findOrFail($id);

        $tangap = Tanggapan::where('pengaduan_id',$id)->first();

        return view('pages.admin.pengaduan.detail',[
            'item' => $item,
            'tangap' => $tangap
        ]);
       
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {


        // $status->update($data);
        return redirect('admin/pengaduans');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pengaduan = Pengaduan::find($id);
        $pengaduan->delete();

        Alert::success('Berhasil', 'Pengaduan telah di hapus');
        return redirect('admin/pengaduans');
    }

    
    
    
    function assessReport(string $description): array {
        $totalScore = 0;
        $descriptionLower = strtolower($description);
    
        // Array kata kunci dan nilai yang sesuai
        $keywords = [
            'sangat parah' => 90,
            'parah' => 40,
            'rusak' => 40,
            'putus' => 40,
            'lubang besar' => 40,
            'jalan putus' => 40,
            'jalan retak' => 40,
            'retak' => 30,
            'tolong' => 40,
            'mohon' => 30,
            'cepat' => 40,
            'secepatnya' => 30,
            'tolonglah' => 30,
            'cepat perbaiki' => 30,
            'banyak lubang' => 30,
            'sangat parah sekali' => 90,
            'susah' => 30,
            'susah lewat' => 30,
            'lewat' => 30,
            'tidak bisa' => 20,
            'diperbaiki' => 30,
            'cepatlah' => 30,
            'datangi' => 20,
            'sangat' => 20,
            'sangat dalam' => 30,
            'terjatuh' => 70,
            'kecelakaan' => 90,
            'parah betol' => 900,
            'tolonglah pak' => 40,
            'ajab' => 30,
            'susah betol' => 40,
            'macam mano' => 20,
            'tepesok' => 40,
            'lewat situ' => 40,
            'lubang' => 40,
            'parah' => 60,
            'Sangat buruk' => 90,
            'Buruk' => 60,
            'Rusak' => 40,
            'Jalan putus' => 60,
            'Lubang besar' => 40,
            'Jalan retak' => 40,
            'Retak' => 60,
            'Permohonan bantuan' => 40,
            'Mohon perbaikan' => 60,
            'Tindakan cepat' => 40,
            'Perbaikan secepatnya' => 60,
            'Permohonan pertolongan' => 40,
            // Tambahkan kata kunci lainnya...
        ];
    
       // Iterasi melalui array kata kunci
    foreach ($keywords as $keyword => $value) {
        $totalScore += substr_count($descriptionLower, $keyword) * $value;
    }

    // Kategorisasi nilai berdasarkan total skor
    $label = '';
    if ($totalScore <= 50) {
        $label = 'Sedang';
    } elseif ($totalScore <= 100) {
        $label = 'Parah';
    } else {
        $label = 'Sangat Parah';
    }

    return ['label' => $label];
}
}