<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RoadController extends Controller
{
    public function calculateSeverityLevel($reportText)
    {
        $keywords = [
            'parah' => 80,
            'sangat' => 50,
            'lubang' => 30,
            // Tambahkan kata-kata lain dan bobotnya sesuai kebutuhan
        ];

        $severityScore = 0;

        // Hitung skor berdasarkan kata-kata dalam laporan
        foreach ($keywords as $keyword => $score) {
            $count = substr_count(strtolower($reportText), $keyword);
            $severityScore += $count * $score;
        }

        return $severityScore;
    }

    public function determineSeverityLevel(Request $request)
    {
        $reportText = $request->input('report_text');

        $severityScore = $this->calculateSeverityLevel($reportText);

        // Tentukan tingkatan level berdasarkan skor
        if ($severityScore >= 80) {
            $severityLevel = 'Tinggi';
        } elseif ($severityScore >= 50) {
            $severityLevel = 'Sedang';
        } else {
            $severityLevel = 'Rendah';
        }

        // Kembalikan tingkatan level
        return response()->json(['severity_level' => $severityLevel]);
    }
}
