<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon;

class Pengaduan extends Model
{
    use SoftDeletes;
    use HasFactory;

    protected $table = 'pengaduan';

    protected $fillable = [
        'name', 'description', 'image', 'status', 'user_nik', 'user_id', 'kecamatan', 'desa', 'jalan', 'province_id'
    ];

    protected $hidden = [];

    public function province()
    {
        return $this->belongsTo(Provinces::class, 'kecamatan');
    }

    public function regency()
    {
        return $this->belongsTo(Regency::class, 'desa');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_nik', 'nik');
    }

    public function details()
    {
        return $this->hasMany(Pengaduan::class, 'id', 'id');
    }

    public function phones()
    {
        return $this->belongsTo(User::class);
    }

    public function tanggapans()
    {
        return $this->belongsTo(Pengaduan::class, 'id', 'id');
    }

    public function tanggapan()
    {
        return $this->hasOne(Tanggapan::class);
    }

    public function status()
    {
        return $this->belongsTo(Tanggapan::class, 'status_id', 'status');
    }

    public function getCreatedAtAttribute($value)
    {
        return Carbon::parse($value)->timezone('Asia/Jakarta');
    }

    // Function utama
    public static function main(): void
    {
        // Input laporan pengguna dari database menggunakan Eloquent
        $reports = self::all()->toArray();
    }
}
