<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddLocationColumnsToPengaduanTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('pengaduan', function (Blueprint $table) {
            $table->unsignedBigInteger('kecamatan')->nullable()->change();
        $table->dropForeign(['province_id']);
        $table->dropColumn('province_id');
            // Tambahkan kolom desa dan jalan
            $table->string('desa')->nullable();
            $table->text('jalan')->nullable();
        });
    }
    
    public function down()
    {
        Schema::table('pengaduan', function (Blueprint $table) {
            // Hapus foreign key
            $table->dropForeign(['province_id']);
    
            // Hapus kolom province_id, desa, dan jalan
            $table->dropColumn(['province_id', 'desa', 'jalan']);
        });
    }
}