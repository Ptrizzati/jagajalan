<!DOCTYPE html>
<html :class="{ 'theme-dark': dark }" x-data="data()" lang="en">


<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"
        integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
  <title>@yield('title') </title>
  
  <link rel="icon" href="{{ asset('img/hero.png') }}" type="image/x-icon">
  <link rel="shortcut icon" href="{{ asset('img/hero.png') }}" type="image/x-icon">

  @include('includes.masyarakat.style')


</head>

<body>
  <div class="flex h-screen bg-gray-50 dark:bg-gray-900" :class="{ 'overflow-hidden': isSideMenuOpen }">

    <div class="flex flex-col flex-1 w-full">

      @include('includes.masyarakat.navbar')

      @yield('content')

      @include('includes.masyarakat.footer')
    </div>
  </div>
  @include('sweetalert::alert')
  @include('includes.masyarakat.script')

  <script>
    $(document).ready(function() {
        $("#selectProv").select2({
            placeholder: 'Pilih Kecamatan',
            ajax: {
                url: "{{ route('provinsi.index') }}",
                processResults: function({ data }) {
                    return {
                        results: $.map(data, function(item) {
                            return {
                                id: item.id,
                                text: item.name
                            };
                        })
                    };
                }
            },
            templateResult: formatResult,  // Fungsi untuk menampilkan opsi di dropdown
            templateSelection: formatSelection  // Fungsi untuk menampilkan opsi yang dipilih
        });

        $("#selectProv").change(function() {
            let id = $('#selectProv').val();

            $("#selectRegenc").select2({
                placeholder: 'Pilih Desa',
                ajax: {
                    url: "{{ url('selectRegenc') }}/" + id,
                    processResults: function({ data }) {
                        return {
                            results: $.map(data, function(item) {
                                return {
                                    id: item.id,
                                    text: item.name
                                };
                            })
                        };
                    }
                },
                templateResult: formatResult,  // Fungsi untuk menampilkan opsi di dropdown
                templateSelection: formatSelection  // Fungsi untuk menampilkan opsi yang dipilih
            });
        });

        // Fungsi untuk menampilkan opsi di dropdown dan yang dipilih
        function formatResult(item) {
            return item.text;  // Menampilkan teks dari opsi
        }

        function formatSelection(item) {
            return item.text;  // Menampilkan teks dari opsi yang dipilih
        }
    });
</script>
</body>

</html>