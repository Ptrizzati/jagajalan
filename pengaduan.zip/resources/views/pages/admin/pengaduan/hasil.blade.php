<?php
// Function untuk mendapatkan koneksi database
function getDatabaseConnection(): PDO {
    $host = 'localhost';
    $dbname = 'pengaduan_masyarakat';
    $username = 'root';
    $password = '';

    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";

    try {
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

// Function untuk mendapatkan laporan pengguna dari database
function getReportsFromDatabase(PDO $pdo): array {
    $statement = $pdo->query("SELECT * FROM pengaduan");
    return $statement->fetchAll(PDO::FETCH_ASSOC);
}

// Function untuk memberikan penilaian berdasarkan kata kunci dalam laporan
function assessReport(string $description): array {
    $score = 0;
    $descriptionLower = strtolower($description);

    // Array kata kunci dan nilai yang sesuai
    $keywords = [
        'sangat parah' => 90,
        'parah' => 60,
        'rusak' => 40,
        'putus' => 60,
        'lubang besar' => 40,
        'jalan putus' => 60,
        'jalan retak' => 40,
        'retak' => 60,
        'tolong' => 40,
        'mohon' => 60,
        'cepat' => 40,
        'secepatnya' => 60,
        'tolonglah' => 40,
        'cepat perbaiki' => 60,
        'banyak lubang' => 40,
        'sangat parah sekali' => 60,
        'susah' => 40,
        'susah lewat' => 60,
        'lewat' => 40,
        'tidak bisa' => 60,
        'diperbaiki' => 40,
        'cepatlah' => 60,
        'datangi' => 40,
        'sangat' => 60,
        'sangat dalam' => 40,
        'terjatuh' => 60,
        'kecelakaan' => 40,
        'parah betol' => 60,
        'tolonglah pak' => 40,
        'ajab' => 60,
        'susah betol' => 40,
        'macam mano' => 60,
        'tepesok' => 40,
        'lewat situ' => 60,
        'lubang' => 40,
        'parah' => 60,
        // Tambahkan kata kunci lainnya...
    ];

    // Iterasi melalui array kata kunci
    foreach ($keywords as $keyword => $value) {
        if (strpos($descriptionLower, $keyword) !== false) {
            $score += $value;
        }
    }

    // Kategorisasi nilai
    $label = '';
    if ($score <= 50) {
        $label = 'Sedang';
    } elseif ($score <= 100) {
        $label = 'Parah';
    } else {
        $label = 'Sangat Parah';
    }

    return ['label' => $label];
}

// Function utama
function main(): void {
    // Mendapatkan koneksi database
    $pdo = getDatabaseConnection();

    // Input laporan pengguna dari database
    $reports = getReportsFromDatabase($pdo);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Penilaian Laporan Pengguna</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 20px;
        }

        h1 {
            text-align: center;
            color: #009688;
        }

        .report-container {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 20px;
        }

        .report-label {
            font-weight: bold;
            font-size: 18px;
            color: #009688;
        }
    </style>
</head>

<body>
   

<?php
    // Menampilkan hasil penilaian untuk setiap laporan
    foreach ($reports as $report) {
        // Mendapatkan nilai penilaian dari deskripsi laporan
        $result = assessReport($report['description']);

        // Menampilkan hasil penilaian
        echo '<div class="report-container">';
        echo '<div class="report-label">Kategori: ' . $result['label'] . '</div>';
        echo '</div>';
    }
?>

</body>

</html>
<?php
}

// Panggil function utama
main();
?>
