<?php

use App\Http\Controllers\IndonesiaController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RoadController;

Route::get('/', function () {
    return view('welcome');
});

// Admin/Petugas
Route::prefix('admin')
    ->middleware(['auth', 'admin'])
    ->group(function() {
        Route::get('/', 'DashboardController@index')->name('dashboard');

        Route::resource('pengaduans', 'PengaduanController');

        Route::resource('tanggapan', 'TanggapanController');

        Route::get('masyarakat', 'AdminController@masyarakat');
        Route::resource('petugas', 'PetugasController');

        Route::get('laporan', 'AdminController@laporan');
        Route::get('laporan/cetak', 'AdminController@cetak');
        Route::get('pengaduan/cetak/{id}', 'AdminController@pdf');
});


// Masyarakat
Route::prefix('user')
    ->middleware(['auth', 'MasyarakatMiddleware'])
    ->group(function() {
		Route::get('/', 'MasyarakatController@index')->name('masyarakat-dashboard');
        Route::resource('pengaduan', 'MasyarakatController');
        Route::get('pengaduan', 'MasyarakatController@lihat');
});

Route::get('indonesia', function(){
    return view('formindonesia');
});


Route::get('selectProv', [IndonesiaController::class, 'provinsi'])->name('provinsi.index');
Route::get('selectRegenc/{id}', [IndonesiaController::class, 'regency']);
Route::get('desa/{id}', [IndonesiaController::class, 'desa']);


Route::post('/calculate-severity-level', [RoadController::class, 'determineSeverityLevel']);

require __DIR__.'/auth.php';
