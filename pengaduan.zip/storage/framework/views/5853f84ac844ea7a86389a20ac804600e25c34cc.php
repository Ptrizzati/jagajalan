<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>JAGA JALAN | Pelaporan Jalan</title>
  
  <style>
    .thead{
    background-color: #FEB139;
    color: #ffffff;
    
    }
  </style>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>

<body>
  <div class="container mt-5">
    <div class="title text-center mb-5">
      <h2>Laporan Layanan Pengaduan Kerusakan Jalan</h2>
    </div>
    <table class="table table-bordered">
      <thead class="thead">
        <tr>
          <th scope="col">No</th>
          <th scope="col">NIK</th>
          <th scope="col">Nama</th>
          <th scope="col">Pengaduan</th>
          <th scope="col">Tanggal</th>
          <th scope="col">Status</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
        <tr>
          <td><?php echo e($item->id); ?> </td>
          <td><?php echo e($item->user_nik); ?></td>
          <td><?php echo e($item->name); ?></td>
          <td><?php echo e($item->description); ?></td>
          <td><?php echo e($item->created_at->format('l, d F Y')); ?></td>
          <td><?php echo e($item->status); ?></td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\pengaduan\resources\views/pages/admin/pengaduan.blade.php ENDPATH**/ ?>