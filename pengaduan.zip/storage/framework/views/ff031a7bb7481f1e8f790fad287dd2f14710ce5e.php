  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
        <div class="text-center">
            © 2023 | By <strong>Team P32R</strong>
        </div>
  </footer><!-- End Footer --><?php /**PATH C:\xampp\htdocs\pengaduan\resources\views/includes/landing/footer.blade.php ENDPATH**/ ?>